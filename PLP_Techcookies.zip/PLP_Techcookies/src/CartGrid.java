import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.os.ProcessUtils.ProcessStillAliveException;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;

public class CartGrid{

	public static void main(String[] args) throws InterruptedException, IOException 

	{
		System.setProperty("webdriver.chromedriver.driver", "D:/chromedriver.exe");
	
		   
		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		capabilities.setBrowserName("chrome");
		capabilities.setCapability("webdriver.chromedriver.driver", "D:/chromedriver.exe");
		

		
		capabilities.setPlatform(Platform.WINDOWS);
		//capabilities.setVersion(version);
		WebDriver driver = new RemoteWebDriver(new URL("http://localhost:6666/wd/hub"), capabilities);
	File src=new File("D:\\123.xlsx");
		
    	FileInputStream fis =new FileInputStream(src); 

    	XSSFWorkbook wb=new XSSFWorkbook(fis);
    		
    	XSSFSheet sheet=wb.getSheetAt(0);
 
		int rowCount=sheet.getLastRowNum();
    	System.out.println(rowCount);
		
    	for(int i=1;i<=rowCount;i++)
  		{
	    		
	    		System.out.println("---------------------------------------------");
	    		System.out.println("Iteration "+i);
	    		driver.get("http://demo.opencart.com");
	    		Thread.sleep(1000);
	    		
	    		try{

	    		System.out.println("Webpage openend");
	    					//Maximizes the browser window
	    		driver.manage().window().maximize() ;
	    		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS) ;
			boolean title=driver.getTitle().contains("Your Store");
			if(title)
			{
				System.out.println("Title matches");
			}
			else
			{
				System.out.println("Title not matches");
			}
			
			driver.findElement(By.linkText("My Account")).click();
			Thread.sleep(1000);
			System.out.println("My Account is clicked");
			
			driver.findElement(By.linkText("Login")).click();
			//Thread.sleep(1000);
			System.out.println("Login is clicked");
		String mail1=sheet.getRow(i).getCell(0).getStringCellValue();
		driver.findElement(By.name("email")).sendKeys(mail1);
		WebElement mail = driver.findElement(By.name("email"));
		String email = mail.getAttribute("value");
		if(DataValidator.Validatemail(email))//Validating email
		{
			System.out.println("Email verified");
		    Thread.sleep(1000);
		    String pass1=sheet.getRow(i).getCell(1).getStringCellValue();
		    driver.findElement(By.name("password")).sendKeys(pass1);
		    Thread.sleep(1000);
		    WebElement pass = driver.findElement(By.name("password"));
			String pwrd = pass.getAttribute("value");
			if(DataValidator.ValidatePass(pwrd))
			{
				driver.findElement(By.xpath("//input[@value='Login']")).click();
				System.out.println("login  successfully");
		        driver.findElement(By.linkText("Edit your account information")).click();
		        Thread.sleep(1000);
		        System.out.println("Edit your account information is clicked");
		        String number1=sheet.getRow(i).getCell(2).getStringCellValue();	
			driver.findElement(By.id("input-telephone")).clear();
			driver.findElement(By.name("telephone")).sendKeys(number1);
		        WebElement Number = driver.findElement(By.id("input-telephone"));
				String number = Number.getAttribute("value");
				if(DataValidator.ValidatePhone(number))
				{
					System.out.println("Phone number verified");
					driver.findElement(By.xpath(".//*[@id='content']/form/div/div[2]/input")).click();
		        	driver.findElement(By.linkText("Modify your address book entries")).click();
		        	Thread.sleep(1000);
			        driver.findElement(By.xpath(".//*[@id='content']/div/div[2]/a")).click();
			        String name1=sheet.getRow(i).getCell(3).getStringCellValue();
			        driver.findElement(By.name("firstname")).sendKeys(name1);
		        	WebElement name = driver.findElement(By.xpath(".//*[@id='input-firstname']"));
					String fname = name.getAttribute("value");
					if(DataValidator.ValidatefName(fname))
					{
						System.out.println("First Name verified");
						String name2=sheet.getRow(i).getCell(4).getStringCellValue();
						driver.findElement(By.name("lastname")).sendKeys(name2);
						WebElement Lname = driver.findElement(By.name("lastname"));
						String lname = Lname.getAttribute("value");
						if(DataValidator.ValidatelName(lname))
						{
							System.out.println("Last Name verified");
							String comp1=sheet.getRow(i).getCell(5).getStringCellValue();
							driver.findElement(By.name("company")).sendKeys(comp1);
							WebElement Comp = driver.findElement(By.name("lastname"));
							String comp = Comp.getAttribute("value");
							if(DataValidator.ValidateCompany(comp))
							{
								System.out.println("Company name verified");
								String addr1=sheet.getRow(i).getCell(6).getStringCellValue();
								driver.findElement(By.name("address_1")).sendKeys(addr1);
			
								WebElement Addr= driver.findElement(By.name("address_1"));
								String addr = Addr.getAttribute("value");
								Thread.sleep(1000);
								if(DataValidator.Validatealpha(addr))
								{
									System.out.println("Address 1 verified");
									driver.findElement(By.name("address_2")).sendKeys("Siruseri");
									String city1=sheet.getRow(i).getCell(7).getStringCellValue();
									driver.findElement(By.name("city")).sendKeys(city1);
									WebElement City = driver.findElement(By.name("city"));
									String city = City.getAttribute("value");
									if(DataValidator.ValidateCity(city))
									{
										System.out.println("City name verified");
										String pin1=sheet.getRow(i).getCell(8).getStringCellValue();
										driver.findElement(By.name("postcode")).sendKeys(pin1);
										WebElement pin2 = driver.findElement(By.name("postcode"));
										String pin3 = pin2.getAttribute("value");
										if(DataValidator.ValidateNumbers(pin3))
										{
										System.out.println("Pincode Verified");
										Select fromCountry= new Select(driver.findElement(By.id("input-country")));
										fromCountry.selectByIndex(106);
										WebElement Country = fromCountry.getFirstSelectedOption();
										String country = Country.getText();
										if(country.equals("India"))
											System.out.println("India is selected");
										else
											System.out.println("Other country is selected");
										
										Select fromState= new Select(driver.findElement(By.id("input-zone")));
										fromState.selectByVisibleText("Tamil Nadu");
										
										WebElement State = fromState.getFirstSelectedOption();
										String state = State.getText();
										if(state.equals("Tamil Nadu"))
											System.out.println("Tamil Nadu state selected");
										else
											System.out.println("Other state selected");
										WebElement radio1 = driver.findElement(By.xpath(".//*[@id='content']/form/fieldset/div[10]/div/label[1]/input "));
										
										radio1.click();
										
										if(radio1.isSelected()){
											System.out.println("yes is selected");
										}
										else
										{
											System.out.println("No is selected");
										}
										driver.findElement(By.xpath(".//*[@id='content']/form/div/div[2]/input")).click();
										if(driver.getPageSource().contains(" Your address has been successfully added"))
										{
											System.out.println("Address succesfully added");
										}
										System.out.println("Closing the browser");
								
										
										}
										
									}
									
									
									}
								}	
							}
						}
					}
				}
			}

		driver.quit();
	    		}
	    		
	    		catch(NullPointerException e)
	    		{
	    			System.out.println("Null Pointer Exception found "+e);
	    			driver.close();
	    		}
	    		catch(ProcessStillAliveException f)
	    		{
	    			System.out.println(" Exception found "+f);
	    			driver.close();
	    		}
	    		catch(InterruptedException g)
	    		{
	    			System.out.println(" Exception found "+g);
	    			driver.close();
	    		}
	    		catch(RuntimeException h)
	    		{
	    			System.out.println(" Exception found "+h);
	    			driver.close();
	    		}
	    		
		}
	    	System.out.println("----------------------------");
	    	System.out.println("End of the project");
	    	System.out.println("----------------------------");
	}
		
}
			

